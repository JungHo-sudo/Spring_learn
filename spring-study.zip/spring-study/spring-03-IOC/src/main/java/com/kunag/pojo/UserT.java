package com.kunag.pojo;

public class UserT {
    private String name;

    public UserT(){
        System.out.println("你爹的无参构造方法已经被实例化了");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void show(){
        System.out.println("name="+name);
    }
}
