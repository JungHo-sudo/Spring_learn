import com.kuang.service.UserService;
import com.kuang.service.UserServiceImpl;

public class MyTest {

    public void test(){
        UserService service = new UserServiceImpl();
        service.getUser();
    }
}
