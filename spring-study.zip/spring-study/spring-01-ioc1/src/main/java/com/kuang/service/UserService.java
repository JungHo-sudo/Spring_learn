package com.kuang.service;

public interface UserService {
    void getUser();
}
