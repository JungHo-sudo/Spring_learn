package com.kuang.demo3;
//等会我们会用到这个类，自动生成代理类！


import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * @author jungho
 */
public class ProxyInvocationHandler implements InvocationHandler {

    /* 被代理的接口 */

    private Rent rent;

    public void setRent(Rent rent) {
        this.rent = rent;
    }
    //生成得到代理类

    public Object getProxy(){
        return Proxy.newProxyInstance(this.getClass().getClassLoader()
                , rent.getClass().getInterfaces(),this);
    }

    // 处理代理实例，并且返回结果

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        //用invoke来执行方法，丢个参数执行完毕反馈result
//        动态代理的本质就是用反射机制实现
        Object result = method.invoke(rent, args);

        return result;
    }
}
