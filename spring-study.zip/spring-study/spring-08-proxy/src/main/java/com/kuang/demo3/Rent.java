package com.kuang.demo3;

public interface Rent {
    public void rent();
}