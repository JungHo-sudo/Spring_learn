package com.kuang.service;


// 业务接口

public interface UserService {
    public void add();
    public void delete();
    public void update();
    public void search();
}