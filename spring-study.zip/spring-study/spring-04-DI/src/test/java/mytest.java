import com.kuang.pojo.Student;
import com.kuang.pojo.User;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

public class mytest {
    public static void main(String[] args) {
      ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Student student = (Student) context.getBean("student");
        System.out.println(student.toString());
//        Student{name='jungho',
//        address=Address{address='仁川'},
//        books=[红楼梦, 水浒传, 三国演义],
//        hobbys=[听歌, 写代码, 玩游戏, 看电影],
//        card={身份证=12345678990, 银行卡=2131251312312, 型号=123123123123123},
//        games=[LOL, LO, LOLLLL],
//        wife='null',
//        info={测试2=2, 学号=32131231, 测试1=1, 性别=男}}
    }


    @Test
    public void test2(){
        ApplicationContext context = new ClassPathXmlApplicationContext("userbeans.xml");
        User user = context.getBean("user2",User.class);
        System.out.println(user);
    }
}
