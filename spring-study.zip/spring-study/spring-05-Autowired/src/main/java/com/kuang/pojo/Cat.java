package com.kuang.pojo;

public class Cat {
    public void shot(){
        System.out.println("miao");
    }
}
