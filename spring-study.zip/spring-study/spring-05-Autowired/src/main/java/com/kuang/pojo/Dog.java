package com.kuang.pojo;

public class Dog {
    public void shot(){
        System.out.println("wang");
    }
}
